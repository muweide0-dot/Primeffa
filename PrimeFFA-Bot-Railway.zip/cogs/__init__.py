"""PrimeFFA Cogs (Module)."""
