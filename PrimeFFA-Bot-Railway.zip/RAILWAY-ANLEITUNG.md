## Railway Deployment

1. Push the contents of this folder to your GitHub repository.
2. Create a Railway project from that GitHub repository.
3. In Railway > Service > Variables, add:
   - Name: DISCORD_TOKEN
   - Value: your newly generated Discord bot token
4. Build Command (if Railway does not install dependencies automatically):
   `pip install -r requirements.txt`
5. Start Command:
   `python bot.py`

The bot reads `DISCORD_TOKEN` from the environment. Do not upload `.env`
or put a real token in GitHub. The `.env` file from the source archive
has intentionally been excluded from this Railway ZIP. Use a newly
generated token because any token previously pasted into chat should
be considered exposed.
